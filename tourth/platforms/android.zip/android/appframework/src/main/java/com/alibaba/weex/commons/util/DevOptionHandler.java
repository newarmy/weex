package com.alibaba.weex.commons.util;

public interface DevOptionHandler {
  void onOptionSelected();
}
